//: .\C03:TESTHEADER_iwchar_traits.cpp
//: C03:iwchar_traits.h {-g++}
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Creating your own wide-character traits.
// We'll only change character-by-
// character comparison functions
// Compare the other wchar_ts
// IWCHAR_TRAITS_H  ///:~
#include"iwchar_traits.h"
int main() {}
